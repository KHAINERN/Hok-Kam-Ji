<?php
require 'config.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token validation failed");
    }

    // Get form data
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Validate inputs
    $errors = [];
    if (empty($username)) {
        $errors[] = "Username/Email is required";
    }
    if (empty($password)) {
        $errors[] = "Password is required";
    }

    if (empty($errors)) {
        // Create database connection
        try {
            $conn = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Prepare SQL to prevent SQL injection
            $stmt = $conn->prepare("SELECT id, username, email, password FROM users WHERE username = :username OR email = :email");
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':email', $username);
            $stmt->execute();

            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                // Verify password (must be hashed with password_hash())
                if (password_verify($password, $user['password'])) {
                    // Authentication successful
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['loggedin'] = true;

                    // Redirect to dashboard
                    header("Location: hkjprojek.html");
                    exit;
                } else {
                    $errors[] = "Invalid username or password";
                }
            } else {
                $errors[] = "Invalid username or password";
            }
        } catch(PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }

    // If we got here, there were errors
    $_SESSION['login_errors'] = $errors;
    header("Location: login.html");
    exit;
} else {
    // Not a POST request
    header("Location: login.html");
    exit;
}
?>